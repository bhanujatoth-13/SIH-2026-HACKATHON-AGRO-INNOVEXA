import React, { useState, useEffect, useRef } from 'react';
import {
  QrCode,
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Scan,
  Camera,
  FileText,
  Phone,
  Building2,
  HelpCircle,
  ArrowRight,
  Upload,
  Video,
  RefreshCw,
  X,
  FlaskConical,
  AlertOctagon,
  Check,
  Printer,
  PackageCheck,
  Sparkles,
  ExternalLink,
  Info,
} from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
import { InputVerificationResult, RegionalLanguage } from '../types';

interface FakeInputScannerProps {
  initialCodeOrName?: string;
  currentLanguage?: RegionalLanguage;
}

interface SampleBottleItem {
  id: string;
  title: string;
  chemical: string;
  category: string;
  status: 'genuine' | 'counterfeit';
  imageUrl: string;
  code: string;
  badge: string;
}

const SAMPLE_BOTTLES: SampleBottleItem[] = [
  {
    id: 'coragen',
    title: 'FMC Coragen 18.5% SC',
    chemical: 'Chlorantraniliprole 18.5% SC',
    category: 'Insecticide (Systemic)',
    status: 'genuine',
    imageUrl: '/samples/coragen-bottle.jpg',
    code: '8901234567890',
    badge: '100% Genuine Sample',
  },
  {
    id: 'confidor',
    title: 'Bayer Confidor 200 SL',
    chemical: 'Imidacloprid 17.8% SL',
    category: 'Insecticide (Neonicotinoid)',
    status: 'genuine',
    imageUrl: '/samples/cotton-crop.jpg',
    code: '8909876543210',
    badge: '100% Genuine Sample',
  },
  {
    id: 'saaf',
    title: 'UPL Saaf Fungicide',
    chemical: 'Carbendazim 12% + Mancozeb 63% WP',
    category: 'Fungicide (Contact & Systemic)',
    status: 'genuine',
    imageUrl: '/samples/wheat-crop.jpg',
    code: '8905544332211',
    badge: '100% Genuine Sample',
  },
  {
    id: 'fake-chlor',
    title: 'Adulterated "Super Chlor" 20% EC',
    chemical: 'Spurious Chemical Residues / Solvents',
    category: 'Spurious Counterfeit',
    status: 'counterfeit',
    imageUrl: '/samples/paddy-blight.jpg',
    code: 'FAKE-CHLOR-001',
    badge: 'Counterfeit Fraud Test',
  },
];

export const FakeInputScanner: React.FC<FakeInputScannerProps> = ({
  initialCodeOrName = '',
  currentLanguage,
}) => {
  const [barcodeInput, setBarcodeInput] = useState(initialCodeOrName);
  const [dealerNameInput, setDealerNameInput] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isAnalyzingBottle, setIsAnalyzingBottle] = useState(false);
  const [result, setResult] = useState<InputVerificationResult | null>(null);
  const [complaintFiled, setComplaintFiled] = useState(false);
  const [activeMode, setActiveMode] = useState<'upload' | 'code'>('upload');

  // Camera & optical barcode scanner state for modal
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanTab, setScanTab] = useState<'camera' | 'upload' | 'samples'>('camera');
  const [uploadedBottlePhoto, setUploadedBottlePhoto] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const mainFileInputRef = useRef<HTMLInputElement | null>(null);
  const mainCameraInputRef = useRef<HTMLInputElement | null>(null);
  const modalFileInputRef = useRef<HTMLInputElement | null>(null);
  const modalCameraInputRef = useRef<HTMLInputElement | null>(null);
  const resultsCardRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (initialCodeOrName) {
      setBarcodeInput(initialCodeOrName);
      handleVerify(initialCodeOrName);
    }
  }, [initialCodeOrName]);

  useEffect(() => {
    if (!isScanning) {
      stopCameraScanner();
      return;
    }
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsScanning(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      stopCameraScanner();
    };
  }, [isScanning]);

  const stopCameraScanner = async () => {
    if (html5QrCodeRef.current) {
      try {
        if (html5QrCodeRef.current.isScanning) {
          await html5QrCodeRef.current.stop();
        }
        await html5QrCodeRef.current.clear();
      } catch (err) {
        console.warn('Notice stopping scanner:', err);
      }
      html5QrCodeRef.current = null;
    }
    setCameraActive(false);
  };

  const startCameraScanner = async () => {
    setCameraError(null);
    try {
      await stopCameraScanner();

      if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraActive(false);
        setCameraError('Live camera video stream is not supported in this browser environment. Please use the Upload Bottle Photo tab.');
        setScanTab('upload');
        return;
      }

      let cameras: Array<{ id: string; label: string }> = [];
      try {
        cameras = await Html5Qrcode.getCameras();
      } catch (e) {
        console.warn('Notice querying camera list:', e);
      }

      if (!cameras || cameras.length === 0) {
        setCameraActive(false);
        setCameraError('No active video camera detected on this device. Please upload a photo of the bottle or pick from verified sample bottles.');
        setScanTab('upload');
        return;
      }

      const qrCodeId = 'kisan-barcode-reader';
      const qrScanner = new Html5Qrcode(qrCodeId);
      html5QrCodeRef.current = qrScanner;

      const backCam = cameras.find((c) => /back|rear|environment|facing\s*back/i.test(c.label));
      const chosenCameraId = backCam ? backCam.id : cameras[0].id;

      const scanConfig = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0,
      };

      const onScanSuccess = (decodedText: string) => {
        stopCameraScanner();
        setIsScanning(false);
        setBarcodeInput(decodedText);
        handleVerify(decodedText);
      };

      try {
        await qrScanner.start(chosenCameraId, scanConfig, onScanSuccess, () => {});
        setCameraActive(true);
      } catch (startErr: any) {
        if (cameras.length > 1 && chosenCameraId !== cameras[0].id) {
          await qrScanner.start(cameras[0].id, scanConfig, onScanSuccess, () => {});
          setCameraActive(true);
        } else {
          throw startErr;
        }
      }
    } catch (err: any) {
      console.warn('Camera initialization notice:', err?.message || err);
      setCameraActive(false);
      setCameraError('Unable to open live video stream. You can upload a photo of the bottle directly.');
      setScanTab('upload');
    }
  };

  const handleOpenScanner = () => {
    setIsScanning(true);
    setScanTab('camera');
  };

  useEffect(() => {
    if (isScanning && scanTab === 'camera') {
      const timer = setTimeout(() => {
        startCameraScanner();
      }, 300);
      return () => clearTimeout(timer);
    } else {
      stopCameraScanner();
    }
  }, [isScanning, scanTab]);

  // Core Bottle Image Analysis Engine
  const analyzeBottleImage = async (fileOrUrl: File | string) => {
    setIsAnalyzingBottle(true);
    setCameraError(null);
    setComplaintFiled(false);

    try {
      let imageBase64: string | undefined = undefined;
      let imageUrl: string | undefined = undefined;

      if (typeof fileOrUrl === 'string') {
        imageUrl = fileOrUrl;
        setUploadedBottlePhoto(fileOrUrl);
      } else {
        const base64Promise = new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(fileOrUrl);
        });
        imageBase64 = await base64Promise;
        setUploadedBottlePhoto(imageBase64);
      }

      const res = await fetch('/api/scan-bottle-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          imageUrl,
          dealerName: dealerNameInput,
        }),
      });

      const data = await res.json();
      if (data.success && data.verification) {
        const enrichedResult: InputVerificationResult = {
          ...data.verification,
          uploadedImageUrl: data.verification.uploadedImageUrl || imageBase64 || imageUrl,
        };
        setResult(enrichedResult);
        if (data.detectedCode) {
          setBarcodeInput(data.detectedCode);
        }
        setIsScanning(false);
        stopCameraScanner();

        // Scroll to results smoothly
        setTimeout(() => {
          resultsCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 150);
      } else {
        throw new Error(data.error || 'Failed to inspect bottle');
      }
    } catch (err: any) {
      console.error('Bottle analysis error:', err);
      setCameraError('AI bottle inspection encountered an error. Please try another photo or enter the batch code manually.');
    } finally {
      setIsAnalyzingBottle(false);
      if (mainFileInputRef.current) mainFileInputRef.current.value = '';
      if (mainCameraInputRef.current) mainCameraInputRef.current.value = '';
      if (modalFileInputRef.current) modalFileInputRef.current.value = '';
      if (modalCameraInputRef.current) modalCameraInputRef.current.value = '';
    }
  };

  const handleMainFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      analyzeBottleImage(file);
    }
  };

  const handleModalFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      analyzeBottleImage(file);
    }
  };

  const handleVerify = async (codeToVerify?: string) => {
    const code = (codeToVerify || barcodeInput).trim();
    if (!code) return;

    setLoading(true);
    setComplaintFiled(false);
    try {
      const res = await fetch('/api/verify-input', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          dealerName: dealerNameInput,
        }),
      });
      const data = await res.json();
      if (data.success && data.verification) {
        setResult(data.verification);
        if (data.verification.uploadedImageUrl) {
          setUploadedBottlePhoto(data.verification.uploadedImageUrl);
        }
        setTimeout(() => {
          resultsCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 150);
      }
    } catch (err) {
      console.error('Input verification error:', err);
    } finally {
      setLoading(false);
      setIsScanning(false);
    }
  };

  const handleSampleBottleSelect = (sample: SampleBottleItem) => {
    setBarcodeInput(sample.code);
    setUploadedBottlePhoto(sample.imageUrl);
    analyzeBottleImage(sample.imageUrl);
  };

  const handleFileComplaint = () => {
    setComplaintFiled(true);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-emerald-500/30 text-emerald-200 border border-emerald-400/30">
                Anti-Counterfeit Protection
              </span>
              <span className="text-xs text-emerald-200 font-medium">CIB&RC & NSC Statutory Registry Authenticator</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Fake Seed & Pesticide Detector
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-2xl leading-relaxed">
              Upload a bottle photo or scan the QR/barcode to inspect the active chemical, CIB&RC registration, batch number, 3D hologram, and tamper seal before purchasing or spraying.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
            <button
              onClick={() => mainCameraInputRef.current?.click()}
              className="px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black text-sm rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Take Bottle Photo</span>
            </button>
            <button
              onClick={handleOpenScanner}
              className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-sm rounded-2xl border border-white/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Scan className="w-4 h-4" />
              <span>Scan QR / Barcode</span>
            </button>
          </div>
        </div>
      </div>

      {/* Hidden file and camera inputs for main view */}
      <input
        ref={mainFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleMainFileUpload}
        id="main-bottle-file-upload"
      />
      <input
        ref={mainCameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleMainFileUpload}
        id="main-bottle-camera-upload"
      />

      {/* Primary Verification Workspace */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-gray-200 shadow-sm space-y-6">
        
        {/* Mode Selector Tabs */}
        <div className="flex items-center p-1.5 bg-gray-100 rounded-2xl text-xs font-black max-w-md">
          <button
            type="button"
            onClick={() => setActiveMode('upload')}
            className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeMode === 'upload'
                ? 'bg-white text-emerald-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Camera className="w-4 h-4 text-emerald-700" />
            <span>Upload Bottle Photo</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('code')}
            className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeMode === 'code'
                ? 'bg-white text-emerald-950 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <QrCode className="w-4 h-4 text-emerald-700" />
            <span>Barcode / Registry Code</span>
          </button>
        </div>

        {/* SECTION 1: UPLOAD BOTTLE PHOTO MODE */}
        {activeMode === 'upload' && (
          <div className="space-y-5">
            {/* Direct Upload & Dropzone Card */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setDragOver(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setDragOver(false);
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setDragOver(false);
                const dropped = e.dataTransfer.files?.[0];
                if (dropped) analyzeBottleImage(dropped);
              }}
              className={`border-2 border-dashed rounded-3xl p-6 sm:p-8 text-center transition-all ${
                dragOver
                  ? 'border-emerald-600 bg-emerald-50/70 scale-[1.01]'
                  : 'border-emerald-300 bg-emerald-50/30 hover:border-emerald-500 hover:bg-emerald-50/50'
              }`}
            >
              {isAnalyzingBottle ? (
                <div className="py-6 flex flex-col items-center justify-center space-y-3">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-emerald-200 border-t-emerald-700 animate-spin" />
                    <Sparkles className="w-6 h-6 text-emerald-600 absolute inset-0 m-auto animate-pulse" />
                  </div>
                  <h3 className="text-base font-black text-emerald-950">
                    Inspecting Pesticide Bottle Packaging...
                  </h3>
                  <p className="text-xs text-emerald-800 max-w-md">
                    Extracting brand name, CIB&RC statutory registration number, active chemical formulation, batch code, hologram film, and seal status via AI Vision.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-xs">
                    <Upload className="w-8 h-8" />
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-base sm:text-lg font-black text-gray-900">
                      Upload Bottle, Container, or Label Photo
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-600 max-w-lg mx-auto">
                      Drag & drop a photograph of the pesticide bottle, seed packet, or fertilizer bag, or snap a high-resolution photo of the printed label.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => mainCameraInputRef.current?.click()}
                      className="w-full sm:w-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md cursor-pointer transition-colors flex items-center justify-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Take Photo with Camera</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => mainFileInputRef.current?.click()}
                      className="w-full sm:w-auto px-6 py-3 bg-white hover:bg-gray-100 text-gray-800 font-bold text-xs sm:text-sm rounded-xl border border-gray-300 shadow-xs cursor-pointer transition-colors flex items-center justify-center gap-2"
                    >
                      <Upload className="w-4 h-4 text-gray-600" />
                      <span>Browse From Device</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Optional Dealer Name for Verification Context */}
            <div className="flex flex-col sm:flex-row items-center gap-3 bg-gray-50 p-4 rounded-2xl border border-gray-200">
              <label className="text-xs font-bold text-gray-700 whitespace-nowrap flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-gray-500" />
                Retail Shop / Dealer Name (Optional):
              </label>
              <input
                type="text"
                value={dealerNameInput}
                onChange={(e) => setDealerNameInput(e.target.value)}
                placeholder="e.g. Mahalaxmi Krishi Seva Kendra, APMC Market"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-gray-300 bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            {/* Quick Sample Bottles Selection */}
            <div className="space-y-2.5 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
                  <PackageCheck className="w-4 h-4 text-emerald-700" />
                  Try Instant Inspection with Verified Bottle Samples:
                </span>
                <span className="text-[11px] text-gray-500 font-medium">Click any sample to test</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {SAMPLE_BOTTLES.map((sample) => (
                  <div
                    key={sample.id}
                    onClick={() => handleSampleBottleSelect(sample)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer hover:shadow-md flex flex-col justify-between space-y-3 ${
                      sample.status === 'genuine'
                        ? 'bg-emerald-50/50 border-emerald-200 hover:border-emerald-400'
                        : 'bg-red-50/50 border-red-200 hover:border-red-400'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-14 h-14 rounded-xl overflow-hidden bg-white border border-gray-200 shrink-0 flex items-center justify-center p-1">
                        <img
                          src={sample.imageUrl}
                          alt={sample.title}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </div>
                      <div className="space-y-1">
                        <span
                          className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md inline-block ${
                            sample.status === 'genuine'
                              ? 'bg-emerald-200 text-emerald-900'
                              : 'bg-red-200 text-red-900'
                          }`}
                        >
                          {sample.badge}
                        </span>
                        <h4 className="text-xs font-black text-gray-900 leading-tight">
                          {sample.title}
                        </h4>
                        <p className="text-[11px] text-gray-600 line-clamp-1">
                          {sample.chemical}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-200/80 flex items-center justify-between text-[11px] font-bold">
                      <span className="text-gray-500">{sample.category}</span>
                      <span
                        className={`flex items-center gap-1 ${
                          sample.status === 'genuine' ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        Inspect <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SECTION 2: BARCODE / REGISTRY CODE MODE */}
        {activeMode === 'code' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-7">
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Enter Barcode, QR Code, or Batch Number
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    placeholder="e.g. 8901234567890 or CORAGEN or FAKE-CHLOR-001"
                    className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                  <QrCode className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div className="sm:col-span-5">
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Retail Dealer Name (Optional)
                </label>
                <input
                  type="text"
                  value={dealerNameInput}
                  onChange={(e) => setDealerNameInput(e.target.value)}
                  placeholder="e.g. Mahalaxmi Krishi Seva Kendra"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-gray-500 uppercase">Test With Sample:</span>
                <button
                  type="button"
                  onClick={() => handleVerify('CORAGEN')}
                  className="text-xs font-bold px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 cursor-pointer"
                >
                  ✓ FMC Coragen
                </button>
                <button
                  type="button"
                  onClick={() => handleVerify('CONFIDOR')}
                  className="text-xs font-bold px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 cursor-pointer"
                >
                  ✓ Bayer Confidor
                </button>
                <button
                  type="button"
                  onClick={() => handleVerify('FAKE-CHLOR-001')}
                  className="text-xs font-bold px-3 py-1.5 rounded-xl bg-red-50 text-red-800 border border-red-200 hover:bg-red-100 cursor-pointer"
                >
                  ⚠️ Counterfeit Chemical
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleVerify()}
                disabled={loading || !barcodeInput.trim()}
                className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs cursor-pointer transition-colors"
              >
                {loading ? 'Verifying Registry...' : 'Authenticate Now'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Optical Scanner Modal */}
      {isScanning && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex justify-center items-start sm:items-center p-3 sm:p-6"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsScanning(false);
            }
          }}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 text-center space-y-4 shadow-2xl my-auto relative animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b pb-3">
              <div className="text-left">
                <h3 className="text-base font-black text-gray-900 flex items-center gap-2">
                  <Scan className="w-5 h-5 text-emerald-700 animate-pulse" />
                  Live Pesticide Bottle Scanner
                </h3>
                <p className="text-[11px] text-gray-500 font-medium">Scan QR code or 1D barcode printed on cap, seal, or label</p>
              </div>
              <button
                type="button"
                onClick={() => setIsScanning(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 font-bold transition-colors cursor-pointer"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            {/* Scan Mode Tabs */}
            <div className="flex items-center p-1 bg-gray-100 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setScanTab('camera')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                  scanTab === 'camera' ? 'bg-white text-emerald-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                Live Camera
              </button>
              <button
                type="button"
                onClick={() => setScanTab('upload')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                  scanTab === 'upload' ? 'bg-white text-emerald-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                Upload Photo
              </button>
              <button
                type="button"
                onClick={() => setScanTab('samples')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                  scanTab === 'samples' ? 'bg-white text-emerald-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                Sample Bottles
              </button>
            </div>

            {/* Camera Viewport */}
            {scanTab === 'camera' && (
              <div className="space-y-3">
                <div className="relative w-full aspect-square max-w-[280px] mx-auto rounded-2xl bg-black overflow-hidden border-2 border-emerald-500 flex items-center justify-center shadow-inner">
                  <div id="kisan-barcode-reader" className="w-full h-full overflow-hidden [&_video]:w-full [&_video]:h-full [&_video]:object-cover" />

                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div className="w-48 h-48 border-2 border-dashed border-emerald-400/80 rounded-xl relative">
                      <div className="absolute top-1/2 left-2 right-2 h-0.5 bg-red-500/90 shadow-sm animate-pulse" />
                      <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                      <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                      <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                    </div>
                  </div>

                  {!cameraActive && !cameraError && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2 text-white p-4">
                      <RefreshCw className="w-6 h-6 animate-spin text-emerald-400" />
                      <p className="text-xs font-semibold">Starting camera feed...</p>
                    </div>
                  )}
                </div>

                {cameraError ? (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-left text-xs text-amber-900 space-y-2">
                    <div className="flex items-center gap-1.5 font-bold text-amber-950">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      Camera Permission Notice
                    </div>
                    <p className="text-[11px] leading-relaxed">{cameraError}</p>
                    <div className="pt-1 flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => modalCameraInputRef.current?.click()}
                        className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold cursor-pointer"
                      >
                        Snap Photo Instead
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSampleBottleSelect(SAMPLE_BOTTLES[0])}
                        className="px-2.5 py-1 bg-white text-emerald-950 border border-emerald-300 rounded-lg text-[10px] font-bold cursor-pointer"
                      >
                        Test Coragen
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-gray-500">
                    Hold bottle 15–20 cm away and center the barcode or QR in the green reticle.
                  </p>
                )}
              </div>
            )}

            {/* Photo Upload Mode inside Modal */}
            {scanTab === 'upload' && (
              <div className="space-y-3">
                <input
                  ref={modalFileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleModalFileUpload}
                  id="modal-file-upload"
                />
                <input
                  ref={modalCameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleModalFileUpload}
                  id="modal-camera-upload"
                />

                {isAnalyzingBottle ? (
                  <div className="w-full aspect-square max-w-[280px] mx-auto border-2 border-dashed border-emerald-400 bg-emerald-50/50 rounded-2xl flex flex-col items-center justify-center p-6 text-center">
                    <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mb-2" />
                    <p className="text-xs font-bold text-emerald-950">Analyzing Bottle Photo...</p>
                    <p className="text-[11px] text-emerald-700">Extracting CIB&RC number, active technical, batch & hologram</p>
                  </div>
                ) : (
                  <div className="w-full aspect-square max-w-[280px] mx-auto border-2 border-dashed border-gray-300 hover:border-emerald-500 rounded-2xl flex flex-col items-center justify-center p-5 text-center transition-colors bg-gray-50/50">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-2">
                      <Camera className="w-6 h-6" />
                    </div>
                    <h4 className="text-xs font-black text-gray-900">Upload Bottle Photo</h4>
                    <p className="text-[11px] text-gray-500 mt-1">Select photo from gallery or snap with camera</p>

                    <div className="flex flex-col sm:flex-row gap-2 mt-3 w-full max-w-[240px]">
                      <button
                        type="button"
                        onClick={() => modalFileInputRef.current?.click()}
                        className="flex-1 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold rounded-lg shadow-xs cursor-pointer"
                      >
                        Browse Files
                      </button>
                      <button
                        type="button"
                        onClick={() => modalCameraInputRef.current?.click()}
                        className="flex-1 px-3 py-2 bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 text-[11px] font-bold rounded-lg shadow-xs cursor-pointer"
                      >
                        Snap Photo
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Sample Bottles Mode inside Modal */}
            {scanTab === 'samples' && (
              <div className="space-y-3 text-left">
                <p className="text-xs text-gray-600 font-medium">
                  Select a verified formulation to test instant verification:
                </p>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {SAMPLE_BOTTLES.map((sample) => (
                    <div
                      key={sample.id}
                      onClick={() => handleSampleBottleSelect(sample)}
                      className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                        sample.status === 'genuine'
                          ? 'border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100/80'
                          : 'border-red-200 bg-red-50/60 hover:bg-red-100/80'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-gray-950">{sample.title}</span>
                        <span
                          className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                            sample.status === 'genuine'
                              ? 'bg-emerald-200 text-emerald-900'
                              : 'bg-red-200 text-red-900'
                          }`}
                        >
                          {sample.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-600 font-mono mt-0.5">{sample.chemical}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={() => setIsScanning(false)}
              className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl cursor-pointer transition-colors"
            >
              Close Scanner
            </button>
          </div>
        </div>
      )}

      {/* COMPREHENSIVE BOTTLE VERIFICATION & INSPECTION RESULTS CARD */}
      {result && (
        <div
          ref={resultsCardRef}
          className={`rounded-3xl p-6 sm:p-7 border shadow-sm space-y-6 ${
            result.status === 'genuine'
              ? 'bg-emerald-50/40 border-emerald-200'
              : result.status === 'counterfeit'
              ? 'bg-red-50/50 border-red-300'
              : 'bg-amber-50/40 border-amber-200'
          }`}
        >
          {/* Header Verdict & Bottle Image Row */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 border-b pb-5">
            <div className="flex items-start gap-4">
              {/* Bottle Photo Thumbnail */}
              {result.uploadedImageUrl ? (
                <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden bg-white border-2 border-gray-200 shadow-sm shrink-0 flex items-center justify-center p-1">
                  <img
                    src={result.uploadedImageUrl}
                    alt={result.productName}
                    className="w-full h-full object-cover rounded-xl"
                  />
                  <div
                    className={`absolute bottom-0 inset-x-0 text-center py-0.5 text-[9px] font-black uppercase text-white ${
                      result.status === 'genuine'
                        ? 'bg-emerald-700'
                        : result.status === 'counterfeit'
                        ? 'bg-red-700'
                        : 'bg-amber-700'
                    }`}
                  >
                    {result.status}
                  </div>
                </div>
              ) : (
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${
                    result.status === 'genuine'
                      ? 'bg-emerald-600 text-white'
                      : result.status === 'counterfeit'
                      ? 'bg-red-600 text-white animate-bounce'
                      : 'bg-amber-600 text-white'
                  }`}
                >
                  {result.status === 'genuine' ? (
                    <ShieldCheck className="w-8 h-8" />
                  ) : (
                    <ShieldAlert className="w-8 h-8" />
                  )}
                </div>
              )}

              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-md ${
                      result.status === 'genuine'
                        ? 'bg-emerald-200 text-emerald-900'
                        : result.status === 'counterfeit'
                        ? 'bg-red-200 text-red-950 font-black'
                        : 'bg-amber-200 text-amber-950'
                    }`}
                  >
                    {result.status === 'genuine'
                      ? '100% VERIFIED GENUINE BOTTLE'
                      : result.status === 'counterfeit'
                      ? '🚨 COUNTERFEIT / FRAUD DETECTED'
                      : '⚠️ SUSPICIOUS / UNVERIFIED PRODUCT'}
                  </span>

                  {result.confidenceScore && (
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-white/80 text-gray-700 border border-gray-200">
                      {result.confidenceScore}% AI Certainty
                    </span>
                  )}
                </div>

                <h3 className="text-xl sm:text-2xl font-black text-gray-900">
                  {result.productName}
                </h3>

                {result.activeChemical && (
                  <p className="text-xs sm:text-sm text-emerald-900 font-bold flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>Technical: {result.activeChemical}</span>
                  </p>
                )}

                <p className="text-xs text-gray-600 font-medium">
                  Manufacturer: <strong>{result.brand}</strong> • Category: {result.category?.toUpperCase()}
                </p>
              </div>
            </div>

            {/* Price & Pack Size */}
            <div className="text-left md:text-right self-stretch md:self-auto bg-white/70 p-3 rounded-2xl border border-gray-200 md:border-none md:bg-transparent">
              <span className="text-[11px] text-gray-500 font-bold uppercase block">Official MRP</span>
              <p className="text-2xl font-black text-gray-900">
                {result.mrpRupees ? `₹${result.mrpRupees}` : 'Unregulated'}
              </p>
              {result.containerVolume && (
                <span className="text-xs font-semibold text-gray-600 block">
                  Pack Size: {result.containerVolume}
                </span>
              )}
            </div>
          </div>

          {/* Warning Banner if Counterfeit */}
          {result.status === 'counterfeit' && (
            <div className="bg-red-100/90 border-2 border-red-500 rounded-2xl p-4 sm:p-5 space-y-2">
              <div className="flex items-center gap-2 text-red-950 font-black text-sm sm:text-base">
                <AlertTriangle className="w-5 h-5 text-red-700 shrink-0" />
                <span>DO NOT SPRAY ON CROPS: Severe Risk of Crop Scorching, Leaf Burn & Soil Poisoning</span>
              </div>
              <ul className="list-disc pl-5 text-xs text-red-900 space-y-1 font-medium">
                {result.warningFlags?.map((flag, idx) => (
                  <li key={idx}>{flag}</li>
                ))}
              </ul>
              <p className="text-xs font-bold text-red-950 pt-1">
                {result.helplineNotice}
              </p>
            </div>
          )}

          {/* CIB&RC Toxicity Triangle & Packaging Security Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Statutory Toxicity Triangle */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-gray-500 font-bold uppercase">CIB&RC Toxicity Class</span>
                <span className="text-[10px] text-gray-400 font-mono">Statutory</span>
              </div>

              <div className="flex items-center gap-2.5">
                <div
                  className={`w-6 h-6 rotate-45 border border-gray-400 shrink-0 ${
                    result.toxicityTriangle === 'red'
                      ? 'bg-red-600'
                      : result.toxicityTriangle === 'yellow'
                      ? 'bg-amber-400'
                      : result.toxicityTriangle === 'blue'
                      ? 'bg-blue-600'
                      : 'bg-emerald-600'
                  }`}
                />
                <div>
                  <span
                    className={`text-xs font-black block ${
                      result.toxicityTriangle === 'red'
                        ? 'text-red-700'
                        : result.toxicityTriangle === 'yellow'
                        ? 'text-amber-800'
                        : result.toxicityTriangle === 'blue'
                        ? 'text-blue-800'
                        : 'text-emerald-800'
                    }`}
                  >
                    {result.toxicityTriangle === 'red'
                      ? 'Red: Extremely Toxic'
                      : result.toxicityTriangle === 'yellow'
                      ? 'Yellow: Highly Toxic'
                      : result.toxicityTriangle === 'blue'
                      ? 'Blue: Moderately Toxic'
                      : 'Green: Slightly Toxic'}
                  </span>
                  <span className="text-[10px] text-gray-500 font-medium">
                    {result.toxicityTriangle === 'red'
                      ? 'तीव्र विष (Fatal Poison)'
                      : result.toxicityTriangle === 'yellow'
                      ? 'विष (Poison)'
                      : result.toxicityTriangle === 'blue'
                      ? 'खतरा (Danger)'
                      : 'सावधान (Caution)'}
                  </span>
                </div>
              </div>
            </div>

            {/* 3D Security Hologram */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 space-y-1 text-xs">
              <span className="text-[11px] text-gray-500 font-bold uppercase block">3D Security Hologram</span>
              <span
                className={`text-xs font-bold mt-1 block flex items-center gap-1 ${
                  result.securityChecks.hologramPatternVerified ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {result.securityChecks.hologramPatternVerified ? '✓ Verified 3D Foil' : '✕ Fake / Missing'}
              </span>
              <p className="text-[11px] text-gray-500">Optical kinetic color-shift film check</p>
            </div>

            {/* Tamper Evident Cap Seal */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 space-y-1 text-xs">
              <span className="text-[11px] text-gray-500 font-bold uppercase block">Tamper Evident Seal</span>
              <span
                className={`text-xs font-bold mt-1 block flex items-center gap-1 ${
                  result.securityChecks.tamperEvidentSeal ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {result.securityChecks.tamperEvidentSeal ? '✓ Thermal Seal Intact' : '✕ Resealed / Broken'}
              </span>
              <p className="text-[11px] text-gray-500">Bottle cap induction heat-seal</p>
            </div>

            {/* Batch Code & Shelf Life */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 space-y-1 text-xs">
              <span className="text-[11px] text-gray-500 font-bold uppercase block">Batch & Expiry Date</span>
              <span
                className={`text-xs font-bold mt-1 block flex items-center gap-1 ${
                  result.securityChecks.batchExpiryValid ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {result.securityChecks.batchExpiryValid ? '✓ Valid (Within Date)' : '✕ Expired / Tampered'}
              </span>
              <p className="text-[11px] text-gray-500">Mfg to Expiry shelf life audit</p>
            </div>
          </div>

          {/* Government Registration & Bottle Batch Details */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-gray-200 text-xs space-y-3">
            <h4 className="text-xs font-black text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-emerald-700" />
              Government Statutory CIB&RC & Batch Record
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-100">
                <span className="text-gray-500 block text-[11px]">Official CIB&RC Reg No:</span>
                <span className="font-mono font-bold text-gray-900 mt-0.5 block break-all">
                  {result.cibrNo}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-100">
                <span className="text-gray-500 block text-[11px]">Batch Number / Lot ID:</span>
                <span className="font-mono font-bold text-gray-900 mt-0.5 block">
                  {result.batchNumber}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-100">
                <span className="text-gray-500 block text-[11px]">Manufacturing & Expiry:</span>
                <span className="font-semibold text-gray-900 mt-0.5 block">
                  Mfg: {result.manufacturingDate} • Exp: {result.expiryDate}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-100 sm:col-span-2">
                <span className="text-gray-500 block text-[11px]">Authorized Retail Dealer:</span>
                <span className="font-semibold text-gray-900 mt-0.5 block">
                  {result.authorizedDealer}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-100">
                <span className="text-gray-500 block text-[11px]">State Agrochemical License:</span>
                <span className="font-mono font-bold text-gray-900 mt-0.5 block">
                  {result.dealerLicenseNo}
                </span>
              </div>
            </div>
          </div>

          {/* AI Inspection Observations (Label Reading Insights) */}
          {result.inspectionNotes && result.inspectionNotes.length > 0 && (
            <div className="bg-white rounded-2xl p-4 sm:p-5 border border-gray-200 text-xs space-y-2">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-700" />
                Physical Label & Packaging Inspection Observations
              </h4>
              <ul className="space-y-1.5 pt-1">
                {result.inspectionNotes.map((note, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-gray-700">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* First Aid & Antidote Advisory */}
          {result.antidoteAdvisory && (
            <div className="bg-amber-50/70 rounded-2xl p-4 border border-amber-200 text-xs text-amber-950 space-y-1">
              <strong className="font-black flex items-center gap-1.5 text-amber-900">
                <AlertOctagon className="w-4 h-4 text-amber-700" />
                Statutory Emergency Antidote & First-Aid Instructions:
              </strong>
              <p className="leading-relaxed">{result.antidoteAdvisory}</p>
            </div>
          )}

          {/* Action Row */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            {result.status === 'counterfeit' && !complaintFiled && (
              <button
                type="button"
                onClick={handleFileComplaint}
                className="w-full sm:w-auto px-5 py-3 bg-red-700 hover:bg-red-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md cursor-pointer transition-colors flex items-center justify-center gap-2"
              >
                <FileText className="w-4 h-4" />
                <span>File 1-Click Fraud Complaint to District Agriculture Officer (DAO)</span>
              </button>
            )}

            {complaintFiled && (
              <div className="bg-emerald-100 text-emerald-950 px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Complaint #DAO-FRAUD-2026-891 lodged with Sub-Divisional Agriculture Office. Enforcement inspector assigned.</span>
              </div>
            )}

            <a
              href="tel:18001801551"
              className="w-full sm:w-auto px-4 py-3 bg-gray-900 hover:bg-black text-white font-bold text-xs sm:text-sm rounded-xl text-center flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Call Kisan Fraud Helpline (1800-180-1551)</span>
            </a>

            <button
              type="button"
              onClick={handlePrint}
              className="w-full sm:w-auto px-4 py-3 bg-white hover:bg-gray-100 text-gray-800 font-bold text-xs sm:text-sm rounded-xl border border-gray-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-gray-600" />
              <span>Print Inspection Slip</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setResult(null);
                setUploadedBottlePhoto(null);
                setBarcodeInput('');
              }}
              className="w-full sm:w-auto px-4 py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-xs sm:text-sm rounded-xl border border-emerald-300 flex items-center justify-center gap-2 cursor-pointer ml-auto"
            >
              <RefreshCw className="w-4 h-4 text-emerald-700" />
              <span>Scan / Upload Another Bottle</span>
            </button>
          </div>
        </div>
      )}

      {/* 5-Point Physical Bottle Inspection Checklist */}
      <div className="bg-gray-50 rounded-3xl p-5 sm:p-6 border border-gray-200 text-xs text-gray-700 space-y-3">
        <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-emerald-700" />
          Farmer Guide: 5 Physical Checks Before Buying Seeds or Pesticides
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-1">
            <strong className="text-gray-900 block font-bold">1. Demand a GST Bill</strong>
            <p className="text-gray-600">Never buy in cash without an official bill. The cash memo must record the product batch number and expiry date.</p>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-1">
            <strong className="text-gray-900 block font-bold">2. Scratch & Verify Hologram</strong>
            <p className="text-gray-600">Authentic agrochemical brands feature a 3D kinetic color-shifting security hologram that changes under sunlight.</p>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-gray-200 space-y-1">
            <strong className="text-gray-900 block font-bold">3. Inspect Container Embossing</strong>
            <p className="text-gray-600">Genuine bottles feature the brand name molded directly into the plastic container base, not just printed on paper.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
